package ru.sapteh;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Program{
	public static void main(String[] args) throws IOException{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("==================[Triangle]==================");
		System.out.println("Enter color:");
		String color = br.readLine();
		System.out.println("Enter coordinate X:");
		int coordinateX = Integer.parseInt(br.readLine());
		System.out.println("Enter coordinate Y:");
		int coordinateY = Integer.parseInt(br.readLine());
		System.out.println("Enter base:");
		int base = Integer.parseInt(br.readLine());
		System.out.println("Enter height:");
		int height = Integer.parseInt(br.readLine());
		
		
		
		System.out.println("==================[Circle]==================");
		System.out.println("Enter color:");
		String colorC = br.readLine();
		System.out.println("Enter coordinate X:");
		int coordinateXC = Integer.parseInt(br.readLine());
		System.out.println("Enter coordinate Y:");
		int coordinateYC = Integer.parseInt(br.readLine());
		System.out.println("Enter radius:");
		int radius = Integer.parseInt(br.readLine());
		
		
		
		System.out.println("==================[Square]==================");
		System.out.println("Enter color:");
		String colorS = br.readLine();
		System.out.println("Enter coordinate X:");
		int coordinateXS = Integer.parseInt(br.readLine());
		System.out.println("Enter coordinate Y:");
		int coordinateYS = Integer.parseInt(br.readLine());
		System.out.println("Enter side:");
		int side = Integer.parseInt(br.readLine());
		
		Triangle triangle = new Triangle(color, coordinateX, coordinateY, base, height);
		Circle circle = new Circle(colorC, coordinateXC, coordinateYC, radius);
		Square square = new Square(colorS, coordinateXS, coordinateYS, side);
		
		System.out.println(triangle.toString());
		System.out.println(circle.toString()) ;
		System.out.println(square.toString());
	}
}