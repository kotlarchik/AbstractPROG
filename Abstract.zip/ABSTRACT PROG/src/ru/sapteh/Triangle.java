package ru.sapteh;
public class Triangle extends Shape{
	private int height;
	private int base;
	
	public Triangle(String color, int coordX, int coordY, int base, int height){
		super(color, coordX, coordY);
		this.base = base;
		this.height = height;
	}
	public int getBase(){
		return base;
	}
	public int getHeight(){
		return height;
	}
	
	@Override
	public String draw(){
		return "Triangle";
	}
	@Override
	public double area(){
		return 0.5 * base * height;
	}
	@Override
	public String toString(){
		
		return String.format("[Triangle]================== \n Draw: %s Color: %s X: %d Y: %d Base: %d Height: %d Area: %.2f", 
		draw(), super.getColor(), super.getCoordX(), super.getCoordY(), getBase(), getHeight(), area());
	}
}