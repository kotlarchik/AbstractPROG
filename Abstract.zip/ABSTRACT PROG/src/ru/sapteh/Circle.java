package ru.sapteh;
public class Circle extends Shape{
	private int radius;

	public Circle(String color, int coordX, int coordY, int radius){
		super(color, coordX, coordY);
		this.radius = radius;
	}
	public int getRadius(){
		return radius;
	}
	
	@Override
	public String draw(){
		return "Circle";
	}
	@Override
	public double area(){
		return Math.PI * (radius * radius);
	}
	@Override
	public String toString(){
		return String.format("[Circle]================== \n Draw: %s Color: %s X: %d Y: %d Radius: %d Area: %.2f", 
		draw(), super.getColor(), super.getCoordX(), super.getCoordY(), getRadius(), area());
	}
}